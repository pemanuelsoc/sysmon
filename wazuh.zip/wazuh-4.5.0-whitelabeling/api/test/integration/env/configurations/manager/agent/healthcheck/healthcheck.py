# No checks are needed as manager tests don't depend on agents
exit(0)
